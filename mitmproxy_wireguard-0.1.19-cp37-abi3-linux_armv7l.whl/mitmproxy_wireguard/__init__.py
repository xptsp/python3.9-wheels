from .mitmproxy_wireguard import *

__doc__ = mitmproxy_wireguard.__doc__
if hasattr(mitmproxy_wireguard, "__all__"):
    __all__ = mitmproxy_wireguard.__all__